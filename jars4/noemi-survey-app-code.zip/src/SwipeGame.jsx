import { useState, useEffect } from 'react';
import TinderCard from 'react-tinder-card';
import { supabase } from './supabaseClient.js';

// Mapping of swipe directions to labels. Feel free to adjust labels
// according to the branding of your survey (e.g. "fuck" → "love").
const CHOICE_MAP = {
  right: 'fuck',
  up: 'marry',
  left: 'kill',
  down: 'not_sure',
};

/**
 * A Tinder-like swipe interface for collecting qualitative feedback on
 * label designs. It fetches the list of designs from the public
 * directory and records each swipe to Supabase.
 */
export default function SwipeGame({ participantId }) {
  const [designs, setDesigns] = useState([]);
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Load the design metadata from the bundled JSON. In production
    // this could be fetched from Supabase or another API.
    const fetchDesigns = async () => {
      try {
        const res = await fetch('/designs/index.json');
        const json = await res.json();
        setDesigns(json);
      } catch (err) {
        console.error(err);
        setError('Failed to load designs');
      } finally {
        setLoading(false);
      }
    };
    fetchDesigns();
  }, []);

  /**
   * Called when the user swipes a card. Inserts a record in the
   * `swipes` table associating the participant with their choice.
   *
   * @param {string} direction The swipe direction (right, up, left, down)
   * @param {string} designId The UUID of the design record
   */
  const handleSwipe = async (direction, designId) => {
    const choice = CHOICE_MAP[direction];
    if (!choice) return;
    // Optimistically advance to the next card
    setIndex((prev) => prev + 1);
    try {
      await supabase.from('swipes').insert({
        participant_id: participantId,
        design_id: designId,
        choice,
      });
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <p>Loading designs…</p>;
  if (error) return <p>{error}</p>;
  if (index >= designs.length) return <p>Thanks for swiping! You’ve completed the session.</p>;

  // Show one design at a time to keep the interface simple. Additional
  // designs will be rendered once the current card has been swiped.
  const current = designs[index];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <h2>Rate this design</h2>
      <div style={{ width: '300px', height: '300px' }}>
        <TinderCard
          key={current.id}
          onSwipe={(dir) => handleSwipe(dir, current.id)}
          preventSwipe={[]}
        >
          <div
            style={{
              backgroundColor: '#fff',
              width: '100%',
              height: '100%',
              borderRadius: '10px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              overflow: 'hidden',
            }}
          >
            <img
              src={current.image_url}
              alt="label design"
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          </div>
        </TinderCard>
      </div>
      <p style={{ marginTop: '1rem', fontStyle: 'italic' }}>
        Swipe right = fuck, up = marry, left = kill, down = not sure
      </p>
    </div>
  );
}